const fs = require('fs');
const readline = require('readline');
const express = require('express');
const app = express();
const PORT = 3000;

const logFilePath = 'logfile.txt'; // Ensure this file exists

const ipCounts = {};
const hourCounts = {};

// Regex to extract IP addresses and hours
const logPattern = /(\d+\.\d+\.\d+\.\d+) - - \[\d{2}\/\w+\/\d{4}:(\d{2}):\d{2}:\d{2}/;

const readStream = fs.createReadStream(logFilePath);
const rl = readline.createInterface({ input: readStream });

rl.on('line', (line) => {
    const match = logPattern.exec(line);
    if (match) {
        const ip = match[1];    // Extract IP Address
        const hour = match[2];  // Extract Hour (00 - 23 format)

        // Count IP occurrences
        ipCounts[ip] = (ipCounts[ip] || 0) + 1;

        // Count hourly traffic
        hourCounts[hour] = (hourCounts[hour] || 0) + 1;
    }
});

rl.on('close', () => {
    console.log("IP Address Count:", ipCounts);
    console.log("Hourly Traffic Count:", hourCounts);
});

// Function to calculate top contributors based on percentage
function getTopContributors(data, percentage) {
    const sortedEntries = Object.entries(data).sort((a, b) => b[1] - a[1]); // Sort descending
    const total = sortedEntries.reduce((sum, [, count]) => sum + count, 0); // Get total count
    let cumulative = 0;
    let result = [];

    for (let [key, count] of sortedEntries) {
        cumulative += count;
        result.push(key);
        if ((cumulative / total) * 100 >= percentage) break; // Stop when reaching percentage
    }

    return result;
}

// Serve API data
app.get('/data', (req, res) => {
    const ip85Percent = getTopContributors(ipCounts, 85);
    const hour70Percent = getTopContributors(hourCounts, 70);

    res.json({
        ipCounts,
        hourCounts,
        ip85Percent,
        hour70Percent
    });
});

// Serve frontend files
app.use(express.static('public'));

app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});
