window.onload = function() {
    fetch('/data')
        .then(res => res.json())
        .then(data => {
            console.log("Raw Data:", data);

            if (!data.ip85Percent || !data.hour70Percent) {
                console.error("Missing ip85Percent or hour70Percent data in the response");
                return;
            }

            console.log("IP Counts:", data.ipCounts);
            console.log("Hour Counts:", data.hourCounts);
            console.log("IP Addresses contributing to 85% of traffic:", data.ip85Percent);
            console.log("Hours contributing to 70% of traffic:", data.hour70Percent);

            // Render IP Chart
            renderIPChart(data.ipCounts);

            // Render Hourly Traffic Chart
            renderHourChart(data.hourCounts);

            // Update top IPs and hours list
            document.getElementById('ip85Percent').innerHTML = data.ip85Percent.map(ip => `<li>${ip}</li>`).join('');
            document.getElementById('hour70Percent').innerHTML = data.hour70Percent.map(hr => `<li>${hr}:00</li>`).join('');
        })
        .catch(err => console.error("Error fetching data:", err));
};

function renderIPChart(ipCounts) {
    const ctx = document.getElementById('ipChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(ipCounts),
            datasets: [{
                label: 'IP Occurrences',
                data: Object.values(ipCounts),
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
            }]
        }
    });
}

function renderHourChart(hourCounts) {
    const ctx = document.getElementById('hourChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(hourCounts),
            datasets: [{
                label: 'Visitors per Hour',
                data: Object.values(hourCounts),
                backgroundColor: 'rgba(255, 99, 132, 0.6)',
            }]
        }
    });
}
