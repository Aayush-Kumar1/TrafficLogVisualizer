# Log Data Histogram

## Description
This project reads log data from a server's log file, processes the data, and presents two types of visualizations:
- **IP Address Traffic**: A histogram showing the number of occurrences for each distinct IP address accessing the server.
- **Hourly Traffic**: A bar chart displaying the number of visitors per hour on a given day.

Additionally, the application provides:
- A list of IP addresses that contribute to 85% of the total traffic.
- A list of hours contributing to 70% of the total traffic.

## Features
- **Histogram** of IP address occurrences.
- **Hourly Traffic Bar Chart** to show visitors per hour.
- **Top IP Addresses contributing to 85% of Traffic**.
- **Top Hours contributing to 70% of Traffic**.

## Technologies Used
- **Node.js**: Backend server to read and process log data.
- **Express.js**: Web framework for creating the API and serving static files.
- **Chart.js**: Frontend library for rendering charts.
- **HTML/CSS**: Basic structure and styling for the frontend.
- **JavaScript**: For both frontend and backend logic.

## How to Run the Application

### Prerequisites
1. Node.js and npm should be installed on your machine.
2. Make sure the log file (`logfile.txt`) is available in the project directory.

### Installation
1. Clone the repository:
   ```bash
   git clone https://github.com/your-repository/log-data-histogram.git